#pragma once
//enum to represent azis to mirror objects
enum Axis{X, Y};